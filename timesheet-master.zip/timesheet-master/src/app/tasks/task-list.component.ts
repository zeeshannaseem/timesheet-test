import { Component,  OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';

@Component({
// tslint:disable-next-line:component-selector
selector: 'task-list',
templateUrl: 'task-list.component.html',
styleUrls: ['../employee/employee.component.scss']
})

export class TaskListComponent implements OnInit {
    tasks: any;
    task: Task;
    constructor(private taskService: TaskService) { }

    ngOnInit() {
        this.taskService.getAllTasks().subscribe(data => {
            this.tasks = data;
        });
    }

    selectTask(id: any): void {
        if (id !== 'SELECT') {
            console.log(id);
          this.task = this.tasks.filter(x => x.id == id);
          console.log(this.task);
        }
      }

}
interface Task {
    id: number;
    name: string;
    description: string;
  }
