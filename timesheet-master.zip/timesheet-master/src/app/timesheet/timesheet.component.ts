import { Component,  OnInit, EventEmitter, Output, Input } from '@angular/core';
import { TaskService } from '../services/task.service';
import { TimeSheetService } from '../services/timesheet.service';
import {EmployeeService} from '../services/employee.service';
import {Days} from './Models/DaysOfWeek';
import {Task, TaskDetail, TimeSheet} from '../timesheet/Models/Task';
import { ActivatedRoute } from '@angular/router';

@Component({
// tslint:disable-next-line:component-selector
selector: 'timesheet-data',
templateUrl: 'timesheet.component.html',
styleUrls: ['../employee/employee.component.scss',
'../timesheet/timesheet.component.scss']
})

export class TimeSheetComponent implements OnInit {
    tasks: any;
    task: Task;
    public days: Days[];
    public takDetail: TaskDetail[] ;
    public model: TaskDetail;
    public day: any;
    timeSheet: TimeSheetDetail;
    taskDetail: TimeSheet;
    data: any;
    employees: any;
    selectedTask: any;
    employeeId: string;
    selectedEmployee: string;

    constructor(private taskService: TaskService,
        private timeSheetService: TimeSheetService,
        private route: ActivatedRoute,
        private employeeService: EmployeeService) { }


    ngOnInit() {
        this.timeSheet = new TimeSheetDetail();
        this.taskService.getAllTasks().subscribe(data => {
            this.tasks = data;
            // tslint:disable-next-line:forin
            for (const i in this.tasks) {
                this.tasks[i].hoursPerDay = this.days;
            }
        });

        this.employeeService.getallemployees().subscribe(data => {
            this.employees = data;
             this.employees.filter(x => x.id === Number(this.employeeId)).map( e => {
                 this.selectedEmployee = e.id;
            });
        });

        this.employeeId = this.route.snapshot.params.id;
            if (this.employeeId != null) {
                this.getTimeSheet(this.employeeId);
            }

        this.days = [
            // tslint:disable-next-line:whitespace
            {id:1,name: 'Monday', hours:0 },
            {id: 2, name: 'Tuesday', hours: 0 },
            {id: 3, name: 'Wednesday', hours: 0 },
            {id: 4, name: 'Thursday', hours: 0},
            {id: 5, name: 'Friday', hours: 0},
            {id: 6, name: 'Saturday', hours: 0 },
            {id: 7, name: 'Sunday', hours: 0 },
        ];

        this.takDetail = [];
    }

    getTimeSheet(empId: string) {
        this.timeSheetService.getTimeSheet(empId).subscribe((json: Object) => {

            this.timeSheet = json as TimeSheetDetail;
            if (this.timeSheet != null) {
                 this.timeSheet.tasks.filter(x => x.id === this.timeSheet.taskID).map(t => {
                    this.selectedTask = t;
                });
                this.selectedTask.hoursPerDay.forEach((item, index) => {
                    this.days.filter(x => x.id ===  item.id).map(data => {
                        this.days[data.id - 1].hours = item.hours;
                    });
            });


            this.timeSheet.tasks.forEach((item, index) => {
                item.hoursPerDay = this.days;
                 });
            }
        });
       }

    selectTask(id): void {
        if (id !== 'SELECT') {
          this.task = this.tasks.filter(x => x.id === Number(id));
        this.timeSheet.taskID = this.task[0].id;

          this.taskService.getTaskDetails(id).subscribe(data => {
            this.data = data;
            this.resetDayHours();
            // tslint:disable-next-line:forin
            for (const i in data) {
                this.days.filter(x => x.id === data[i].dayOfWeek).map(d => {
                    this.days[this.data[i].dayOfWeek - 1].hours = data[i].hours;
                });
            }
            // tslint:disable-next-line:forin
        });
        }
      }

      getSelectedEmp(id) {
        this.resetDayHours();
          this.getTimeSheet(id);
      }

      logHours() {
          this.timeSheetService.logTime(this.timeSheet).subscribe(result => {
              alert('Hours logged successfully');
          });
      }

      getSum(index: number): number {
        let sum = 0;
          sum += this.days[index].hours;
        return sum;
      }

      resetDayHours() {
        this.days.forEach((item, index) => {
                this.days[index].hours = 0;
        });
      }
}


class TimeSheetDetail {
    hoursPerDay: Days[];
    constructor() {}
    taskID: number;
    hours: number;
    dayOfWeek: number;
    employeeId: number;
    tasks: Task[];
    timesheetmasterid: number;
}
