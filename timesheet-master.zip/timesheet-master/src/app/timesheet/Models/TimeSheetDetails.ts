import {Task} from '../Models/Task';


export class TimeSheetDetail {
    constructor() {}
    taskID: number;
    hours: number;
    dayOfWeek: number;
    employeeId: number;
    tasks: Task[];
    timesheetmasterid: number;
}

