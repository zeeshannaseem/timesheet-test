import {DaysOfWeek, Days} from './DaysOfWeek';


export class Task {
    constructor() {}
    id: number;
    name: string;
    description: string;
    selected: 0;
    hoursPerDay: Days[];
  }

export  class TaskDetail {
      constructor() { this.Value = []; }
    Task1: string;
    Value: DaysOfWeek[];
}

export  class TimeSheet {
  constructor() {  }
employeeId: number;
taskId: number;
dayOfWeek: number;
hours: number;
}
