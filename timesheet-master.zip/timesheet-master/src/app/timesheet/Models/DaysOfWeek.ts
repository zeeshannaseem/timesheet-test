export  class Days {
    id: number;
  name: string;
  hours: number;
}


export  class DaysOfWeek {
    constructor() { this.hours = 0; }
      name: string;
      hours: number;
  }
