import { Component,  OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
// tslint:disable-next-line:component-selector
selector: 'employee-list-dropdown',
templateUrl: 'timesheet.employeelist.dropdown.html'
})

export class EmployeeListDropdownComponent implements OnInit {
    employees: any;
    employee: Employee;
    employeeId: string;

    @Input() selectedEmployee: string;
    @Input() employeeSelected: string;

    @Output() selectedValueChange = new EventEmitter<string>();

    constructor(private employeeService: EmployeeService, private route: ActivatedRoute) { }

    ngOnInit() {
      this.employeeId = this.route.snapshot.params.id;
        this.employeeService.getallemployees().subscribe(data => {
            this.employees = data;

            this.employees.filter(x => x.id === Number(this.employeeId)).map( e => {
              this.employeeSelected = e.id;
        });
    });
  }
    getName(id: any, event: Event): void {
        if (id !== 'SELECT') {
            this.selectedEmployee = id;
            this.selectedValueChange.emit(this.selectedEmployee);
          this.employee = this.employees.filter(x => x.id === id);
        }
    }

}
interface Employee {
    id: number;
    name: string;
    code: string;
  }
