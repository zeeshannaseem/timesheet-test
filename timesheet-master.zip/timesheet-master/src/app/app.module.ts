import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee.component';
import { EmployeeService } from './services/employee.service';
import { EmployeeListDropdownComponent } from '../app/timesheet/timesheet.employeeslist.dropdown';
import { TimeSheetComponent } from '../app/timesheet/timesheet.component';
import { TaskListComponent } from '../app/tasks/task-list.component';
import { TimeSheetService } from './services/timesheet.service';
import { TaskService } from './services/task.service';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'employees',
    pathMatch: 'full'
  },
  {
    path: '',
    component: AppComponent
  }
  ,
  {
    path: 'employees',
    component: EmployeeListComponent
  }
  ,
  {
    path: 'timesheet/:id',
    component: TimeSheetComponent
  }
  ];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    TimeSheetComponent,
    EmployeeListDropdownComponent,
    TaskListComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  exports: [
    RouterModule
  ],
  providers: [
    EmployeeService,
    TimeSheetService,
    TaskService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
