import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { HttpParams, HttpClient } from '@angular/common/http';
import { TimeSheetDetail } from '../timesheet/Models/TimeSheetDetails';
import { Observable } from 'rxjs';

@Injectable()
export class TimeSheetService {
    private baseapi = environment.apiUrl;
    constructor(private http: HttpClient) { }

    getTimeSheet(id: string) {
        let params = new HttpParams();
        params = params.append('employeeId', id);
        return this.http.get(this.baseapi + '/timesheet/gettimesheet', { params: params });
    }

    logTime(data: TimeSheetDetail): Observable<TimeSheetDetail> {
        return this.http.post<TimeSheetDetail>(this.baseapi + '/timesheet/logTimeSheet', data);
    }


}
