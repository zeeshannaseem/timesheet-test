import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { HttpParams,HttpClient } from '@angular/common/http';

@Injectable()
    export class TaskService {
private baseapi = environment.apiUrl;
constructor(private hhtp: HttpClient) {}
        getAllTasks() {
            // tslint:disable-next-line:whitespace
            return this.hhtp.get(this.baseapi+'/task/gettasks') ;
        }

        getTaskDetails(id: string) {
            let params = new HttpParams();
        params = params.append('taskId', id);
            return this.hhtp.get(this.baseapi + '/timesheet/getTimeSheetByTaskId', { params: params });
        }
    }
